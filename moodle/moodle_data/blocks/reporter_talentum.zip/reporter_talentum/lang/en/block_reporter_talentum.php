<?php


defined('MOODLE_INTERNAL') || die();

$string['pluginname']= 'Reports and enrollment talentum';
$string['title'] = 'Talentum Reporters';
$string['menuTitle']='Reports Configuration';

