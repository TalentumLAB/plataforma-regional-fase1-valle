<?php


defined('MOODLE_INTERNAL') || die();

$string['pluginname']= 'Reportes y matriculación talentum';
$string['title'] = 'Reportes Talentum';
$string['menuTitle']='Configuracion Reportes';
