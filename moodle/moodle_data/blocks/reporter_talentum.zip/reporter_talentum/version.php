<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_reporter_talentum';  
$plugin->version = 2022101501;  // YYYYMMDDHH (year, month, day, 24-hr time)
$plugin->requires = 2018120300;  //moodle 3.6 