<?php
/**
*Cadenas de idioma 'es
*
*@package local_course_dev
*@copyright 2022 andresfelipe
*@license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
*/

$string['pluginname']= 'Reportes y matriculación talentum';
$string['title']='Talentum reportes y matriculación';
$string['menuTitle']='Configuracion Reportes';

/** config strings */
$string['cfg_local_test_key']='Titulo de prueba de configuracion';
$string['cfg_local_test_desc']='descripcion del input en los settings';